const mimeTypesMap = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  // Add other mappings as needed
};

export default mimeTypesMap;
